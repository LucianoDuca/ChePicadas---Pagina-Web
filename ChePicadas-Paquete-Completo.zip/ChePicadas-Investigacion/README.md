# CHE PICADAS — Carpeta de investigación
**Fase 1 de 2.** Recopilación de información previa al desarrollo del sitio web.
Relevamiento: 23 de julio de 2026.

---

## Contenido

```
ChePicadas-Investigacion/
├── 00_DOSSIER_ChePicadas.pdf     ← El documento principal (8 páginas)
├── 01_Dossier_completo.md         ← Fuente en Markdown del dossier
├── 02_Brief_web.md                ← Arquitectura, copy y decisiones de diseño
├── README.md                      ← Este archivo
├── data/
│   ├── sucursales.json            ← Datos estructurados de ambas sedes
│   ├── menu_precios.csv           ← Carta con precios reales de referencia
│   ├── paleta_marca.json          ← Paleta propuesta + tipografía + arte
│   └── fuentes_y_enlaces.csv      ← 25 fuentes con evaluación de fiabilidad
└── media/
    └── INDICE_MEDIA.md            ← URLs de logo, fotos y video + checklist
```

El PDF contiene el dossier y el brief unificados. Los `.md` son la fuente editable.

---

## Resumen de lo encontrado

**Che Picadas** es un almacén de picadas / bodegón argentino nacido en **Mar del Plata alrededor de 2004**, creado por **Emanuel**. Tiene **dos locales**: la casa matriz marplatense en el barrio Güemes y una sucursal abierta en **octubre de 2020** en Arístides Villanueva, Mendoza.

Acumula **más de 16.600 reseñas de Google con un promedio superior a 4,3★** y **158.000 seguidores** entre las dos cuentas de Instagram.

**Su diferencial real no es la comida: es el local.** Un almacén retro tapizado de banderines, chapas enlozadas y antigüedades que la gente filma y compara con *Volver al Futuro*. Ese es el activo que debe organizar todo el sitio.

**Su argumento comercial más repetido:** la picada es para dos personas y comen tres.

---

## Advertencias importantes

1. **No pude descargar archivos multimedia.** El entorno tiene la red restringida a repositorios de desarrollo. En `media/INDICE_MEDIA.md` están todas las URLs directas para bajarlas manualmente.

2. **La paleta de colores es una propuesta, no un dato.** No hay manual de marca público. Hay que validarla contra el logo vectorial real.

3. **El año 2004 es una deducción**, no un dato oficial. Se calcula a partir de una nota de 2020 que menciona «16 años de trayectoria».

4. **Un agregador (carta.menu) publica 2,6★ para Mendoza**, contradiciendo el 4,3★ de Google sobre el mismo local. No usar ese dato.

5. **Hay datos que solo el cliente puede confirmar** — están listados en la sección 9.3 del dossier.

---

## Próximo paso

Validar los datos pendientes, conseguir el logo vectorial y el material fotográfico propio, y pasar a la fase de diseño. El brief (`02_Brief_web.md`) ya tiene la arquitectura de información, las líneas de copy y las decisiones de dirección de arte propuestas.
