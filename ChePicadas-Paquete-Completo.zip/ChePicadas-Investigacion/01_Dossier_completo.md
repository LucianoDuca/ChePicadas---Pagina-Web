# DOSSIER CHE PICADAS
### Investigación previa al desarrollo del sitio web
**Fecha de relevamiento:** 23 de julio de 2026
**Objetivo:** consolidar toda la información pública verificable de la marca Che Picadas para usarla como insumo del diseño y la redacción del sitio web.

---

## 1. IDENTIFICACIÓN DE LA MARCA

| Campo | Dato |
|---|---|
| Nombre comercial | **Che Picadas** |
| Categoría | Almacén de picadas / bodegón / parrilla argentina |
| Descriptor propio (Facebook) | «¡Almacén de picadas!» |
| Descriptor propio (Mendoza, IG) | «Un lugar Mendocino y Marplatense con historia — BODEGÓN & PARRILLA ARGENTINA» |
| Origen | Mar del Plata, Provincia de Buenos Aires, Argentina |
| Año de fundación (estimado) | **≈ 2004** |
| Fundador / dueño | **Emanuel** (apellido no publicado en fuentes abiertas) |
| Locales activos | 2 (Mar del Plata y Ciudad de Mendoza) |
| Dominio oficial | chepicadas.com.ar |

**Nota sobre el año de fundación:** una nota de prensa de octubre de 2020 describe a la marca como «desde hace ya 16 años brindando las mejores picadas de Mar del Plata». De ahí se deduce **2004** como año de inicio. No hay una fuente oficial que lo confirme de forma explícita: conviene validarlo con el cliente antes de publicarlo en el sitio.

---

## 2. HISTORIA Y RELATO DE MARCA

### 2.1 Origen marplatense
Che Picadas nace en **Mar del Plata**, en el barrio Güemes, en la esquina de **San Lorenzo y Olavarría**. Es un proyecto de **Emanuel**, quien sigue siendo el responsable del crecimiento de la marca y de mantener su esencia.

La propuesta original: **comida abundante, ambiente relajado y precios accesibles**. No es una parrilla clásica ni una cafetería de paso: adopta el espíritu del **bodegón argentino**, donde la comida es generosa, sabrosa y directa.

### 2.2 El concepto de "almacén retro"
El diferencial más fuerte de la marca —y el que más se repite en reseñas, blogs y videos de TikTok— **no es solo la comida: es la ambientación**.

- El local está descrito como *«un viaje por el túnel del tiempo donde encontrarás antigüedades, imágenes, curiosidades»*.
- Paredes empapeladas de **banderines** y **objetos retro** de piso a techo.
- Creadores de contenido lo comparan con entrar a *Volver al Futuro*; se lo llama «almacén retro», «museo de antigüedades», «ochentoso».
- Blogs gastronómicos destacan que la decoración es lo primero que enamora al entrar.

> **Esto es oro para el sitio web.** El valor diferencial de Che Picadas es *espacial y nostálgico*. La web tiene que transmitir "almacén de barrio de los 80" antes que "restaurante genérico con fotos de comida".

### 2.3 Crecimiento: llegada a Mendoza (2020)
En **octubre de 2020**, en plena pandemia, Che Picadas abre su sucursal en **Arístides Villanueva 282/284**, Ciudad de Mendoza — uno de los polos gastronómicos más activos del país.

El desembarco funcionó: hoy el local mendocino tiene **más del doble de reseñas de Google que el marplatense** (11.500 vs. 5.100) y se consolidó como parada obligada de la Arístides, con terraza y azotea con vista a la ciudad.

### 2.4 Evolución del producto
Aunque el nombre remite a las tablas de fiambres, la marca **evolucionó hacia la parrilla**:
- Cortes a la llama / **carne a la llama (asador)**
- Parrilladas y platos para compartir
- Incorporación de opciones **vegetarianas y veganas**
- **Patio de juegos** en la sede de Mendoza (perfil familiar)

### 2.5 Famosos que pasaron por el local
Reportado por prensa mendocina (Ecos.ar, dic. 2025):
**Matías Alé · Patricia Sosa · L-Gante** (junto a Agustín Laiseca) · futbolistas de **Independiente Rivadavia** ("la Lepra" mendocina) · **La K'onga** · el ministro del Interior **Luis Petri**.

---

## 3. SUCURSALES

### 3.1 Mar del Plata (casa matriz)

| Campo | Dato |
|---|---|
| Dirección actual | **Olavarría 3325**, B7602CYG Mar del Plata, Buenos Aires |
| Dirección histórica | San Lorenzo esq. José V. de Olavarría (San Lorenzo 1400 / 2898; Olavarría 3199) |
| Coordenadas | -38.018553, -57.545644 |
| Teléfono / Reservas | +54 223 654-7977 |
| WhatsApp | +54 223 635-7854 |
| Teléfono histórico | 0223 451-9342 |
| Email histórico | elchecafe@hotmail.com |
| Barrio | Güemes (Centro Comercial Güemes) |
| Google Rating | **4,4 ★** — 5.093 reseñas |
| Rango de precio | $$ (aprox. ARS 18.000–20.000+ por persona) |
| Horarios | Lun–Sáb 12:00–01:30 · Dom 18:00–01:30 |
| Horario declarado en IG | Lun–Sáb desde 10:00 · Dom desde 18:00 · Delivery 19:00–21:00 |
| Delivery | Rappi (18:00–23:59) + delivery propio |

> **Ojo, dato a verificar:** hay una discrepancia de horarios entre Google (12:00) e Instagram (10:00). Confirmar con el cliente antes de publicar.

### 3.2 Mendoza

| Campo | Dato |
|---|---|
| Dirección | **Arístides Villanueva 284** (algunas fuentes: 282), M5500 Ciudad de Mendoza |
| Coordenadas | -32.892660, -68.854502 |
| Teléfono | +54 261 418-4052 |
| Teléfono alternativo | +54 261 700-1281 |
| Apertura | Octubre de 2020 |
| Google Rating | **4,3 ★** — 11.529 reseñas |
| Horarios | Todos los días 12:00–01:00 |
| Rango de precio | $$ (ARS 20.000–30.000 por persona) |
| Características | Terraza · Azotea con vista a la ciudad · Patio de juegos · Pet friendly · Accesible en silla de ruedas · Reservas · Tarjetas · Take away |
| Transporte público | Parada Belgrano a 411 m |
| Rankings locales | #5 de 885 restaurantes de Mendoza (RestaurantGuru) · #9 comida rápida · #12 pizza · #12 vegetariano (carta.menu) |

---

## 4. CANALES DIGITALES ACTUALES

| Canal | Handle / URL | Audiencia |
|---|---|---|
| Instagram MdP | @chepicadasmdp | ~46.000 seguidores · 457 posts |
| Instagram Mendoza | @chepicadasmendoza | ~112.000 seguidores · 405 posts |
| Facebook | /chepicadas.mardelplata | ~29.145 likes |
| X (Twitter) | @Chepicadasmdq | ~1.682 seguidores (inactivo desde 2011) |
| Sitio web | chepicadas.com.ar | Activo pero bloquea rastreo automático |
| TikTok | Sin cuenta oficial detectada | Fuerte presencia en UGC (#chepicadas, #chepicadasmdq) |
| Delivery | Rappi (MdP), PedidosYa | — |

### Diagnóstico digital rápido
- **La marca es fuerte en Instagram y débil en web.** 158.000 seguidores combinados en IG vs. un sitio web que ni siquiera permite indexación.
- **El sitio actual (chepicadas.com.ar) tiene `robots` restrictivo**, lo que significa que buena parte del contenido no se está indexando bien en Google. Esto es un problema de SEO real y una oportunidad clara para el nuevo sitio.
- **No hay TikTok oficial** pese a que la marca genera muchísimo contenido orgánico de terceros ahí. Oportunidad.
- **No hay reservas online propias**, solo teléfono/WhatsApp.
- **Las dos sucursales operan con identidades digitales separadas** (dos IG, dos teléfonos, un solo dominio). El sitio debería resolver esto con un selector de sede claro.

---

## 5. CARTA Y PRODUCTO

### 5.1 Las picadas (producto insignia)
La estructura de la picada de Che Picadas es su firma: **se divide en parte fría y parte caliente**, lo que la convierte en una comida completa y no en una entrada.

**Parte fría — fiambres:**
jamón cocido · jamón crudo serrano / ibérico · bondiola · lomo ahumado · matambre casero · panceta ahumada · mortadela italiana · salame milán · cantimpalo · salamín picado fino · salamín picado grueso · salamín candelario · longaniza colorada · longaniza calabresa

**Parte fría — quesos:**
pategrás · roquefort · gouda · fontina · sardo · quesos saborizados · queso azul

**Complementos fríos:**
aceitunas · ensalada rusa de la casa · hojas verdes · arándanos · avellanas · almendras

**Parte caliente:**
cazuela de chorizo a la pomarola · cazuela de albóndigas al fileto · salchicha parrillera con tuco · tortilla de papa

### 5.2 Resto de la carta
Parrilla y carne a la llama (asador) · parrilladas para compartir · pizzas · empanadas · milanesas (incluida la «mila gigante») · mariscos y cazuelas (cazuela de mariscos, gambas al ajillo, mejillones a la provenzal) · rabas · lomitos · hamburguesas · comida mexicana · «delicias alemanas» · opciones vegetarianas y veganas · postres (torta de chocolate, flan)

### 5.3 Bebidas
Cervezas artesanales, nacionales e internacionales · **cervezas saborizadas** (muy mencionadas en reseñas) · vinos · tragos · limonada · **happy hour 2x1**

### 5.4 Precios de referencia
*(Rappi Mar del Plata, última actualización pública detectada; precios argentinos, sujetos a inflación — reconfirmar antes de publicar)*

| Plato | Descripción | Precio |
|---|---|---|
| Picada Clásica | Parte fría + parte caliente, para 2 | $30.000 |
| Picada Che | Fiambres, quesos, ensalada rusa, arándanos, avellanas, almendras, para 2 | $35.000 |
| Menú Criolla | Asado, pollo, chorizo, morcilla, pechito de cerdo, salchicha parrillera, papas, para 2 | $35.000 |
| Combo Burger | 2 hamburguesas completas + papas, para 2 | $40.000 |
| ½ kg Picada Che | Variedad de fiambres, quesos y aceitunas | $40.300 |
| Picada Argentina | + empanadas de carne, pollo y j&q, para 2 | $42.000 |
| Menú Valenciana | 2 empanadas de atún, arroz y mariscos de temporada, para 2 | $45.000 |

**Mendoza:** los platos arrancan en **$20.000**. Parrilla para 2 personas ≈ **$42.000**. Se entrega **picada de cortesía gratis** al sentarse.

### 5.5 La regla de oro de la marca
> «La picada que es para 2 la comen tranquilamente 3 personas.»

Este es el argumento comercial más repetido en prensa, reseñas y videos. **Debe ser un pilar del copy del sitio.**

---

## 6. ANÁLISIS DE REPUTACIÓN

### 6.1 Volumen y puntaje

| Fuente | Puntaje | Reseñas |
|---|---|---|
| Google — Mar del Plata | 4,4 / 5 | 5.093 |
| Google — Mendoza | 4,3 / 5 | 11.529 |
| RestaurantGuru — MdP | 4,3 / 5 | 4.756 (+273 fotos, 1 video) |
| Urbano CA — Mendoza | 8,0 / 10 | 2.916 |
| carta.menu — Mendoza | 2,6 / 5 | 7.283 |

> **Advertencia metodológica:** el 2,6 de carta.menu contradice fuertemente el 4,3 de Google sobre el mismo local. Es un agregador de terceros con muestreo distinto. **No usar ese dato en el sitio.** Los datos de Google son los más confiables por volumen y trazabilidad.

**Cifra combinada útil para el sitio: más de 16.600 reseñas de Google con un promedio superior a 4,3★.** Eso es prueba social de primer nivel.

### 6.2 Lo que la gente elogia (usar en el sitio)
- **Abundancia de las porciones** — el punto #1, mencionado en prácticamente todas las reseñas positivas
- **Ambientación y decoración retro** — «lo mejor es la ambientación», «lugar hermoso», «si estás en Mardel es un must»
- **Relación precio/calidad**
- **Atención personalizada** — los clientes nombran a los mozos por su nombre (Vanesa, Lucía, Andrés, Sergio, Mariano, Facundo, Gabriel, Darío, Ciro, Nicolás)
- **Cervezas saborizadas y artesanales**
- **Picada de cortesía / detalles gratis** (postres de regalo, tablita de cortesía)
- **Pet friendly** y apto para chicos
- **Opciones vegetarianas contundentes** (la picada vegetariana tiene fans)

### 6.3 Lo que la gente critica (a tener en cuenta, no publicar)
- **Demoras en horarios pico**, especialmente de noche en Mendoza
- **Inconsistencia en la parrilla** — quejas puntuales sobre costillar y cortes con mucha grasa
- **Papas fritas** — crítica recurrente
- **Picadas "repetitivas"** — la base es la misma en casi todas las tablas, cambia el complemento
- **Promotores en la vereda** (Mendoza) — al menos una reseña dice que la insistencia lo hizo irse a otro lugar
- **Brecha entre la foto del menú y el plato servido** — crítica dura y repetida

> **Implicancia directa para el sitio web:** la última crítica es crucial. **Las fotos del sitio tienen que ser reales y honestas.** Fotos infladas o de banco de imágenes van a amplificar exactamente el reclamo que más daño le hace a la marca.

---

## 7. POSICIONAMIENTO Y COMPETENCIA

### 7.1 Propuesta de valor identificada
**Che Picadas vende abundancia, nostalgia y encuentro — no vende alta cocina.**

Los tres pilares reales de la marca:
1. **Cantidad** — comés de más por lo que pagás
2. **Ambientación** — el local es una atracción en sí mismo
3. **Encuentro** — está diseñado para grupos, familias y amigos, no para cenas de a dos

### 7.2 Competencia directa
**En Mendoza (Arístides Villanueva):** El Club de la Milanesa (Arístides 405) · Hannk Arístides Parrillada · El Patio Jesús María · Estilo Burgers (opera dentro de Che Picadas, Arístides 284) · Papanato (Arístides 386) · Sabores del Perú · El Mercadito Friendly & Fresh

**En Mar del Plata:** el barrio Güemes concentra la oferta gastronómica; la competencia es amplia y fragmentada.

### 7.3 Público objetivo
- **Grupos de amigos y familias** (núcleo duro)
- **Turistas** — es crítico en ambas ciudades: Mar del Plata en verano, Mendoza todo el año
- **Público local recurrente** — «pasan los años y Che Picadas sigue siendo una de las mejores opciones»
- **Segmento familiar con chicos** (patio de juegos en Mendoza)
- **Dueños de mascotas** (pet friendly)

---

## 8. IDENTIDAD VISUAL

### 8.1 Lo que sabemos con certeza
- El local es de estética **almacén de ramos generales / bodegón retro argentino**
- Elementos visuales dominantes en el espacio: **banderines**, chapas y carteles enlozados publicitarios antiguos, objetos ochentosos, madera, antigüedades acumuladas
- El nombre juega con el **«che» argentino** — identidad nacional explícita, reforzada por la bandera 🇦🇷 en la bio de Instagram
- El logo oficial existe en alta calidad en el perfil de Rappi: `images.rappi.com.ar/restaurants_logo/23-1719588681964.png`

### 8.2 Paleta propuesta *(a validar contra el logo oficial)*
No hay una paleta de marca publicada oficialmente. La siguiente es una **propuesta derivada de la estética del local**, no un dato extraído del manual de marca. Debe contrastarse con el logo real antes de fijarla.

| Rol | Color | Hex | Justificación |
|---|---|---|---|
| Primario | Rojo bodegón | `#B5262C` | Rojo de cartelería enlozada antigua y de la tradición del bodegón |
| Secundario | Crema envejecida | `#F2E4C9` | Papel viejo / pared de almacén, base cálida para el fondo |
| Acento | Amarillo mostaza | `#E0A526` | Banderines, carteles vintage, contraste alto para CTAs |
| Neutro oscuro | Marrón madera | `#3A2A20` | Tipografía y estructura; evoca mostrador y estanterías |
| Apoyo | Verde botella | `#2F5D50` | Botellas de cerveza, aceitunas; equilibra la calidez |
| Apoyo | Celeste argentino | `#74ACDF` | Uso puntual, refuerza el "che" argentino sin caer en el cliché |

### 8.3 Dirección tipográfica sugerida
- **Títulos:** una display condensada tipo cartelería de almacén / letra pintada de fileteado (evitar fileteado literal, puede quedar caricaturesco)
- **Cuerpo:** una sans humanista, legible, sin pretensiones
- **Acentos:** una script o slab retro usada con mucha moderación, solo para el nombre y frases sueltas

### 8.4 Recomendación de dirección de arte
El error más probable sería hacer un sitio de restaurante moderno-minimalista. **Eso mataría el activo principal de la marca.** La web debería sentirse como cruzar la puerta del local: cálida, saturada de textura, con fotos reales del espacio, y con un orden claro que evite que el caos visual se vuelva ilegible.

---

## 9. CONCLUSIONES PARA EL SITIO WEB

### 9.1 Activos a explotar
1. **16.600+ reseñas de Google, 4,3★+** → prueba social masiva, arriba de todo
2. **Historia de 20+ años** desde Mar del Plata → credibilidad
3. **La ambientación retro** → contenido visual único e irrepetible
4. **158.000 seguidores en Instagram** → feed embebido, tráfico cruzado
5. **La regla "para 2 comen 3"** → gancho de copy inmejorable
6. **Famosos que pasaron por el local** → prueba social secundaria

### 9.2 Problemas a resolver
1. Sitio actual **no indexable** → SEO local desde cero
2. **Sin reservas online** → oportunidad de conversión directa
3. **Dos sucursales sin unificación digital** → arquitectura con selector de sede
4. **Sin carta digital actualizada y pública** → hoy la gente la encuentra en agregadores de terceros con datos viejos
5. **Sin TikTok oficial** pese a viralidad orgánica
6. **Riesgo de expectativa vs. realidad** → fotografía honesta y verificable

### 9.3 Datos pendientes de confirmar con el cliente
- [ ] Año exacto de fundación y la historia real del origen
- [ ] Apellido completo del fundador y si quiere aparecer
- [ ] Logo oficial en vectorial (SVG/AI) y colores hex reales
- [ ] Carta completa y actualizada con precios vigentes de ambas sedes
- [ ] Horarios reales confirmados (hay contradicción Google vs. Instagram)
- [ ] Fotografía profesional propia con derechos cedidos
- [ ] ¿Hay planes de franquicia o nuevas sucursales?
- [ ] ¿Se quiere integrar reservas y/o pedidos online propios?
- [ ] Dirección exacta de Mendoza: ¿282 o 284?

---

## 10. NOTA SOBRE LA DESCARGA DE ARCHIVOS

El entorno donde se ejecutó esta investigación **tiene la salida de red restringida** a repositorios de desarrollo (GitHub, PyPI, npm). Por eso **no fue posible descargar físicamente las imágenes, videos ni el logo** a la carpeta.

En su lugar, el archivo `media/INDICE_MEDIA.md` contiene **el índice completo de URLs directas** de todo el material visual localizado, listo para descargar manualmente o desde una máquina con acceso abierto.

Para el sitio definitivo, de todos modos, **lo correcto es pedirle al cliente el material original**: usar fotos tomadas de Google, TikTok o agregadores implica un problema de derechos de autor y de calidad.

---

*Documento elaborado a partir de fuentes públicas. Todos los datos son verificables en el archivo `data/fuentes_y_enlaces.csv`.*

---

# ADDENDUM — SEGUNDA PASADA DE VERIFICACIÓN

*Hallazgos de la verificación adicional del 23/07/2026. Estos datos corrigen y amplían el cuerpo principal.*

## A.1 La picada de 21 platitos: el corazón histórico de la marca

El hallazgo más valioso de toda la investigación. **Radio Nacional (Nacional Folklórica) entrevistó en febrero de 2022 a Patricia Muñoz, a cargo del restaurante**, sobre la emblemática **picada de 21 platitos**:

- La tradición de la picada de 21 platitos en Mar del Plata **viene, al menos, de la década del 50**.
- «Hay fotos de los años 60 y 70 de **grandes actores y actrices** con la emblemática picada de 21 platitos».
- Los clientes en TripAdvisor la califican de «mortal»: es el plato con nombre propio más mencionado de la casa.
- En Mendoza (dato UGC, oct. 2025) la 21 platitos para 2 personas costaba **$28.000**, con opciones frías y calientes.

**Implicancia:** Che Picadas no vende solo "picadas abundantes" — es heredero y custodio de una **tradición gastronómica marplatense de 70 años**. Esto merece una sección propia en el sitio y probablemente el lugar central del relato de marca. La entrevista completa en audio está disponible (ver índice de media).

## A.2 Nueva persona clave: Patricia Muñoz

Además de Emanuel (fundador, según Ecos.ar), **Patricia Muñoz figura como "a cargo del restaurante marplatense"** en Radio Nacional (2022). Rol exacto sin confirmar: ¿socia, encargada, familiar? **Preguntar al cliente.**

## A.3 El local cerrado de Constitución

El diario **La Capital de Mar del Plata** registró un robo en un local de Che Picadas **en la zona de Constitución, «cerrado desde junio»**, en plena pandemia (2020). Esto confirma que la frase «sus dos locales» de la nota de octubre de 2020 refería a **dos locales marplatenses**: el de Güemes (activo) y el de Av. Constitución (cerrado en pandemia).

**Historia corregida:** Güemes (casa original) → segundo local en Constitución → cierre por pandemia (2020) → apertura de Mendoza (octubre 2020). La marca no se achicó: se mudó de ciudad.

## A.4 Mecánica comercial actual de Mendoza (verificada por UGC, oct. 2025)

- **Menú de dos pasos:** picada de entrada **gratis** + tabla principal a elección
- **11 opciones de tablas**, disponibles para 2, 3 o 4 personas
- Tablas desde **$20.000** (2 pers.) y **$38.000** (4 pers.)
- Tabla mexicana (4 pers.): **$45.000**
- Costillar a la llama con papas: **$23.000**
- Picada 21 platitos (2 pers.): **$28.000**
- **Menú infantil** y **picadas vegetarianas**
- Juegos para niños dentro del local

## A.5 Detalles de carta confirmados (blog Paladar Negro, MdP)

- Al sentarse sirven **antipasto de cortesía con pan casero** (la cortesía de bienvenida es política de la casa en ambas sedes, no solo Mendoza).
- **Picada Marina**: parte fría de 15 fiambres y quesos + parte caliente de **cazuela de mariscos, gambas al ajillo y mejillones a la provenzal**. Confirma la línea de mar de la casa matriz costera.
- Otra reseña menciona **sopa de verduras de cortesía** como entrada en invierno.

## A.6 Video oficial/semioficial localizado

Existe un video de YouTube titulado **«21 PLATITOS PARA DEGUSTAR | "CHE PICADAS"»** (`youtube.com/watch?v=VvafNC_Gv2g`). Origen por confirmar (¿producción propia o de un medio?).

## A.7 Correcciones a la lista de pendientes con el cliente

Se agregan a la sección 9.3:
- [ ] Confirmar rol de Patricia Muñoz y si aparece en el sitio
- [ ] Historia del local de Constitución: ¿se cuenta o se omite?
- [ ] ¿Existen las fotos históricas de actores de los 60/70 con la picada de 21 platitos? **Si existen, son el activo visual más valioso posible para la sección de historia.**
- [ ] Confirmar si la 21 platitos se sirve en ambas sedes y su precio actual
