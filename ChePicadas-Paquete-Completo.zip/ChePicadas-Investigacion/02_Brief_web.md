# BRIEF WEB — CHE PICADAS
### Insumo para la fase de diseño y desarrollo
*Derivado del dossier de investigación. Este documento propone; no reemplaza la validación con el cliente.*

---

## 1. OBJETIVO DEL SITIO

**Objetivo primario:** que la persona reserve mesa o llegue al local.
**Objetivo secundario:** que entienda, antes de llegar, que va a comer mucho, gastar poco y entrar a un lugar que parece un museo.

**Métricas de éxito sugeridas:**
- Clics en "Reservar" / WhatsApp
- Clics en "Cómo llegar"
- Descargas o vistas de la carta
- Posicionamiento en "picadas Mar del Plata" y "restaurante Arístides Villanueva"

---

## 2. ARQUITECTURA DE INFORMACIÓN

```
INICIO
├── Selector de sede (Mar del Plata / Mendoza) ← decisión temprana, persistente
├── Hero: el local, no el plato
├── Prueba social (16.600+ reseñas · 4,3★)
├── "La picada para 2 la comen 3" — propuesta de valor
├── Vistazo a la carta (3-4 destacados con foto real)
├── El almacén (galería del espacio retro)
└── CTA doble: Reservar · Cómo llegar

LA CARTA
├── Picadas (parte fría / parte caliente explicado visualmente)
├── Parrilla y carne a la llama
├── Cocina (pizzas, empanadas, milanesas, mariscos, mexicana)
├── Vegetariano y vegano
├── Bebidas (artesanales, saborizadas, vinos, happy hour)
└── Descargar carta en PDF

NUESTRA HISTORIA
├── 2004 · Mar del Plata, San Lorenzo y Olavarría
├── El almacén: por qué está lleno de banderines
├── 2020 · Mendoza, la Arístides
└── Hoy: dos casas, la misma mesa

SUCURSALES
├── Mar del Plata — mapa, horarios, teléfono, WhatsApp, delivery
└── Mendoza — mapa, horarios, teléfono, terraza, azotea, patio de juegos

RESERVAS
└── Formulario + WhatsApp directo por sede

CONTACTO / EVENTOS
└── Grupos grandes, cumpleaños, eventos
```

---

## 3. DECISIONES DE DISEÑO CLAVE

### 3.1 El selector de sede es lo primero
Las dos sedes tienen carta, horarios, teléfono y personalidad parcialmente distintos. Forzar al usuario a navegar contenido que no le sirve es la principal fuente de fricción. Selector arriba, sticky, con la elección recordada.

### 3.2 El hero muestra el LOCAL, no el plato
Este es el punto más importante del brief. Todos los competidores muestran un plato en primer plano. **Che Picadas tiene algo que ninguno tiene: un espacio que la gente fotografía por sí solo.** El hero tiene que ser una foto amplia del interior con los banderines y las antigüedades.

### 3.3 Fotografía honesta, obligatoriamente
La crítica más dañina en las reseñas es la brecha entre la foto del menú y el plato real. Ninguna foto de stock. Ninguna foto retocada más allá de color y luz. Si una foto no se puede replicar en la mesa, no va.

### 3.4 Textura sí, minimalismo no
Fondos con textura de papel/madera, bordes de cartel enlozado, tipografía con carácter. Pero con jerarquía estricta: el caos es del local, no de la navegación.

### 3.5 Mobile primero, en serio
El caso de uso real es alguien parado en la Arístides o en Güemes decidiendo dónde entrar. Tiempo de carga, botón de WhatsApp flotante y "Cómo llegar" a un toque.

---

## 4. COPY — LÍNEAS DE TRABAJO

**Titulares candidatos para el hero:**
- «La picada es para dos. Comen tres.»
- «Un almacén de picadas desde 2004.»
- «Entrás a comer. Salís habiendo viajado.»
- «Mar del Plata y Mendoza. La misma mesa.»

**Bloque de prueba social:**
> Más de 16.600 personas nos calificaron en Google. Promedio: 4,3 estrellas.

**Bloque de historia (borrador):**
> Empezó en una esquina de Mar del Plata: San Lorenzo y Olavarría. Una idea simple —picadas abundantes, precio justo, sin protocolo— y unas paredes que se fueron llenando de banderines, chapas viejas y cosas que alguien alguna vez trajo. Nunca dejamos de sumar. Veinte años después, seguimos con el mismo criterio y con una casa más, en la Arístides mendocina.

**Bloque de picada (explicando el diferencial):**
> Nuestra picada tiene dos partes. La fría: catorce fiambres, seis quesos, ensalada rusa de la casa, aceitunas, frutos secos. La caliente: cazuela de chorizo a la pomarola, albóndigas al fileto, salchicha parrillera con tuco y tortilla de papa. No es una entrada. Es la comida.

**Tono de voz:** porteño-costero, directo, con humor seco. Nunca solemne, nunca gourmet, nunca corporativo. Trata de vos.

---

## 5. FUNCIONALIDAD PROPUESTA

### Imprescindible (v1)
- [ ] Selector de sede persistente
- [ ] Carta digital navegable + PDF descargable, por sede
- [ ] Botón WhatsApp flotante con número según sede
- [ ] Google Maps embebido por sede
- [ ] Horarios con indicador "Abierto ahora / Cerrado"
- [ ] Galería del local
- [ ] Schema.org `Restaurant` + `LocalBusiness` para SEO local
- [ ] Metadatos y sitemap indexables (corregir el error del sitio actual)

### Deseable (v2)
- [ ] Reservas online con confirmación automática
- [ ] Feed de Instagram embebido por sede
- [ ] Sección de eventos y grupos grandes
- [ ] Multi-idioma ES/EN (relevante por el turismo internacional en Mendoza)
- [ ] Enlaces a Rappi / PedidosYa

### Evaluar
- [ ] Pedidos online propios (evita comisión de apps, pero requiere logística)
- [ ] Gift cards / vouchers (ya hacen sorteos de vouchers por Instagram)

---

## 6. SEO LOCAL — PRIORIDAD ALTA

El sitio actual bloquea el rastreo automático, lo que significa que Che Picadas está compitiendo en Google **con contenido de terceros** (TripAdvisor, RestaurantGuru, carta.menu) en lugar de con contenido propio. Peor: uno de esos terceros publica un puntaje de 2,6★ que no refleja la realidad.

**Palabras clave objetivo:**
`picadas Mar del Plata` · `almacén de picadas` · `restaurante Güemes Mar del Plata` · `dónde comer en Arístides Villanueva` · `picadas Mendoza` · `bodegón Mendoza` · `parrilla Arístides` · `restaurante para grupos Mar del Plata`

**Acciones:**
1. Corregir robots.txt y permitir indexación completa
2. Una landing por sede, con dirección, teléfono y horarios en HTML plano (no en imagen)
3. Datos estructurados Restaurant con `aggregateRating`, `menu`, `openingHours`, `geo`
4. Reclamar y optimizar ambas fichas de Google Business Profile
5. Coherencia NAP (nombre, dirección, teléfono) idéntica en todos los directorios

---

## 7. RIESGOS

| Riesgo | Mitigación |
|---|---|
| Diseñar un sitio moderno-minimalista genérico | Anclar cada decisión en la estética del local real |
| Usar fotos de terceros sin derechos | Exigir material propio del cliente antes de maquetar |
| Publicar precios que quedan viejos en semanas | Carta con precios editables por el cliente, o sin precios y PDF actualizable |
| El caos visual retro vuelve el sitio ilegible | Textura en fondos, limpieza absoluta en tipografía y navegación |
| Confusión entre las dos sedes | Selector persistente + señalización clara en cada página |

---

## 8. PRÓXIMO PASO

Con este dossier validado, la fase siguiente es:
1. Confirmar con el cliente los datos marcados como pendientes (sección 9.3 del dossier)
2. Conseguir logo vectorial y paleta real
3. Definir la dirección de arte con 2-3 propuestas de moodboard
4. Maquetar el home y una página interna como prueba de concepto
