# ÍNDICE DE MATERIAL VISUAL — CHE PICADAS

> **Por qué esta carpeta está vacía de archivos:** el entorno donde corrió la investigación tiene la salida de red limitada a repositorios de desarrollo (GitHub, PyPI, npm). No pude descargar imágenes ni videos directamente. Abajo están todas las URLs directas localizadas, listas para bajar desde cualquier máquina con acceso normal.
>
> **Advertencia legal:** casi todo este material es de terceros (Rappi, agregadores, usuarios de TikTok, blogs). Sirve como **referencia** para diseño, no como material publicable. Para el sitio definitivo hay que pedirle al cliente el material original o producir fotografía propia.

---

## 1. LOGO

| Recurso | URL | Notas |
|---|---|---|
| Logo oficial (PNG) | `https://images.rappi.com.ar/restaurants_logo/23-1719588681964.png` | La versión de mayor calidad localizada en fuentes públicas. Quitar los parámetros `?e=webp&d=10x10&q=10` de la URL para obtener el original. |
| Banner / imagen de fondo | `https://images.rappi.com.ar/restaurants_background/18-1719588683366.jpg` | Idem: quitar parámetros de compresión. |

**Pendiente crítico:** pedirle al cliente el **logo vectorial (SVG o AI)**. Ningún logo rasterizado sirve para un sitio bien hecho.

---

## 2. FOTOGRAFÍA DE PRODUCTO (Rappi, Mar del Plata)

Todas en `https://images.rappi.com.ar/products/`. Quitar los parámetros de la URL para obtener resolución completa.

| Plato | Archivo |
|---|---|
| Menú Valenciana | `2113119209-1719588777609.jpg` |
| Menú Criolla | `2113119211-1719588743144.jpg` |
| Combo Burger | `2113119206-1719588743137.jpg` |
| Picada Clásica | `2113119207-1719588743143.jpg` |
| Picada Che | `2113119208-1719588743140.jpg` |
| Picada Argentina | `2113119210-1719588743136.jpg` |
| ½ kg Picada Che | `c50ae5c8-5fae-4c3d-9273-098c28297377.png` |

---

## 3. FOTOGRAFÍA DEL LOCAL

### Mendoza
- Exterior: `https://esa-cdn.carta.menu/storage/media/company_gallery/55171677/conversions/contribution_gallery.jpg`
- Interior: `https://esa-cdn.carta.menu/storage/media/company_gallery/55171682/conversions/contribution_gallery.jpg`
- Thumbnail: `https://esa-cdn.carta.menu/storage/media/company_images/55171675/conversions/thumbnail.jpg`

### Mar del Plata
- Google Maps — Place ID `ChIJk3P7eCXchJURVfQFygYPmFU` → fotos de usuarios en alta calidad
- TripAdvisor — galería de fotos de usuarios
- RestaurantGuru — **273 fotos + 1 video** en `https://es.restaurantguru.com/Che-Picadas-Mar-del-Plata`
- Yelp — 15 fotos en `https://www.yelp.com/biz/che-picadas-mar-del-plata`

### La mejor fuente de fotos del ambiente retro
El blog **Paladar Negro** (`https://paladarnegrocomida.blogspot.com/2016/01/che-picadas-mar-del-plata.html`) tiene la crónica más detallada de la decoración con banderines y objetos retro, con fotos propias del local.

---

## 4. VIDEO

No hay canal oficial de YouTube ni TikTok. Todo el video es contenido generado por usuarios:

| Contenido | Dónde |
|---|---|
| Recorrido del "almacén retro" de Mar del Plata | TikTok, hashtag `#chepicadasmdq` — creador *Locura Campestre* |
| "La mila gigante" y precios de Mendoza | TikTok, `https://www.tiktok.com/discover/che-picadas-mendoza` |
| Reseñas de la parrillada de Mendoza | TikTok, varios creadores |
| Sorteo de voucher $300.000 (feb. 2026) | Colaboración con `@misanios90` en Instagram |
| Reels de ambas sedes | Instagram `@chepicadasmdp` y `@chepicadasmendoza` |

---

## 5. QUÉ PEDIRLE AL CLIENTE

Checklist de material a solicitar antes de empezar a maquetar:

- [ ] Logo en **vectorial** (SVG / AI / EPS), con versiones en positivo, negativo y monocromo
- [ ] Colores de marca en **hex** (los del manual, si existe)
- [ ] Tipografías de marca o licencia de uso
- [ ] **Fotografía profesional del interior** de ambos locales (el activo más importante del sitio)
- [ ] Fotografía de producto **honesta**, del plato tal como sale a la mesa
- [ ] Retratos del equipo y del fundador, si quiere aparecer
- [ ] Video corto del ambiente para el hero (10-15 s, sin audio, en loop)
- [ ] Carta completa y actualizada de ambas sedes, en texto editable
- [ ] Material histórico: fotos viejas del local original, si las tiene — sería oro para la sección de historia

---

## 6. NOTA SOBRE DERECHOS

Las fotos de Google Maps, TripAdvisor y TikTok pertenecen a los usuarios que las subieron. Las de Rappi tienen licencia acordada entre Rappi y el restaurante, y no necesariamente permiten reutilización en un sitio propio. **Nada de esto va al sitio final sin autorización explícita.**

---

## 7. NUEVO MATERIAL (segunda pasada)

### Audio — entrevista histórica
- **Entrevista a Patricia Muñoz** (Radio Nacional Folklórica, feb. 2022) sobre la picada de 21 platitos:
  `https://cdn.radionacional.com.ar/wp-content/uploads/2022/02/patricia-munoz-picadas_0.0-634.0.mp3`
  Es la única fuente en primera persona localizada. Escucharla completa antes de escribir la sección de historia.

### Fotos de la picada de 21 platitos (Radio Nacional)
- `https://cdn.radionacional.com.ar/wp-content/uploads/2022/02/platitos.jpg`
- `https://cdn.radionacional.com.ar/wp-content/uploads/2022/02/platitos510.jpg`

### Video
- **«21 PLATITOS PARA DEGUSTAR | "CHE PICADAS"»** — `https://www.youtube.com/watch?v=VvafNC_Gv2g`

### El tesoro a buscar
Según la entrevista, **existen fotos de los años 60 y 70 de grandes actores y actrices con la picada de 21 platitos**. Si el cliente las tiene o sabe dónde están, son el mejor material posible para el sitio. Preguntarlo explícitamente.
